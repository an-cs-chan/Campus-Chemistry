//
//  RootViewController.h
//  Campus_Chemistry
//
//  Created by Trevor Sweetland on 12-03-01.
//  Copyright 2012 University of Manitoba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
}

@end
